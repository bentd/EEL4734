#ifndef HEADER_C
#define HEADER_C

void print_c();

#endif // MY_HEADER_H