#include <iostream>
#include "a.h"

using namespace std;

void print_b()
{
    cout << "A.cpp implementation of A.h print_a";
}

void print_c()
{
    cout << "A.cpp implementation of C.h print_c";
}

int main()
{
    // Your code here

    return 0;
}