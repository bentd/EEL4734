#ifndef HEADER_A
#define HEADER_A

#include "c.h"

void print_a();

#endif // MY_HEADER_H