#include <iostream>
#include "c.h"

using namespace std;

void print_c()
{
    cout << "C.cpp implementation of C.h print_c";
}

int main()
{
    // Your code here

    return 0;
}