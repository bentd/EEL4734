#include <iostream>
#include "b.h"
#include "c.h"

using namespace std;

void print_b()
{
    cout << "B.cpp implementation of B.h print_b";
}

void print_c()
{
    cout << "B.cpp implementation of C.h print_c";
}

int main()
{
    // Your code here

    return 0;
}