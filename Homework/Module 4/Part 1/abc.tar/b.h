#ifndef HEADER_B
#define HEADER_B

void print_b();

#endif // MY_HEADER_H